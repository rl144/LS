using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veigar__TTMOE
{
    internal class NewBuff
    {
        public string DisplayName { set; get; }
        public string Name { set; get; }
        public string MenuName { set; get; }
    }

    internal class NewIgnore
    {
        public string DisplayName { set; get; }
        public string Name { set; get; }
        public string MenuName { set; get; }
    }
}
