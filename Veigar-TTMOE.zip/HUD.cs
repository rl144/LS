using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veigar__TTMOE
{
    internal class HUD
    {
        public string DisplayTextON { set; get; }
        public string DisplayTextOFF { set; get; }
        public string MenuText { set; get; }
        public string MenuComboText { set; get; }
    }
}
